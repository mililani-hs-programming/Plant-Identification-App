
.. _example:

=======
Example
=======

Source
======

.. literalinclude:: example.py
   :caption: `example.py <http://github.com/numpy/numpydoc/blob/master/doc/example.py>`_
   :language: python

Rendered
========

.. automodule:: example
    :members:
