*************
Release Notes
*************

.. include:: ../release/1.15.1-notes.rst
.. include:: ../release/1.15.0-notes.rst
.. include:: ../release/1.14.5-notes.rst
.. include:: ../release/1.14.4-notes.rst
.. include:: ../release/1.14.3-notes.rst
.. include:: ../release/1.14.2-notes.rst
.. include:: ../release/1.14.1-notes.rst
.. include:: ../release/1.14.0-notes.rst
.. include:: ../release/1.13.3-notes.rst
.. include:: ../release/1.13.2-notes.rst
.. include:: ../release/1.13.1-notes.rst
.. include:: ../release/1.13.0-notes.rst
.. include:: ../release/1.12.1-notes.rst
.. include:: ../release/1.12.0-notes.rst
.. include:: ../release/1.11.3-notes.rst
.. include:: ../release/1.11.2-notes.rst
.. include:: ../release/1.11.1-notes.rst
.. include:: ../release/1.11.0-notes.rst
.. include:: ../release/1.10.4-notes.rst
.. include:: ../release/1.10.3-notes.rst
.. include:: ../release/1.10.2-notes.rst
.. include:: ../release/1.10.1-notes.rst
.. include:: ../release/1.10.0-notes.rst
.. include:: ../release/1.9.2-notes.rst
.. include:: ../release/1.9.1-notes.rst
.. include:: ../release/1.9.0-notes.rst
.. include:: ../release/1.8.2-notes.rst
.. include:: ../release/1.8.1-notes.rst
.. include:: ../release/1.8.0-notes.rst
.. include:: ../release/1.7.2-notes.rst
.. include:: ../release/1.7.1-notes.rst
.. include:: ../release/1.7.0-notes.rst
.. include:: ../release/1.6.2-notes.rst
.. include:: ../release/1.6.1-notes.rst
.. include:: ../release/1.6.0-notes.rst
.. include:: ../release/1.5.0-notes.rst
.. include:: ../release/1.4.0-notes.rst
.. include:: ../release/1.3.0-notes.rst

