*************
Miscellaneous
*************

.. automodule:: numpy.doc.misc
